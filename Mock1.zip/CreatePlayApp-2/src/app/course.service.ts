import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Courses } from './courses';
import "rxjs/add/observable/of"

@Injectable()
export class CourseService {
  coursesArr: Courses[] = [
    { id: 1, courseName: "HTML", coursePrice: 100, courseDuration: 15 },
    { id: 2, courseName: "CSS", coursePrice: 100, courseDuration: 25 },
    { id: 3, courseName: "Bootstrap", coursePrice: 100, courseDuration: 35 }
  ]
  constructor(private http:HttpClient) { }
  getCourseData():Observable<any>{
  return  this.http.get("./assets/courses.json")
  }
  AddCourse(courseObj:Courses){
this.coursesArr.push(courseObj)
  }
  getCourse():Observable<Courses[]>{
    return Observable.of(this.coursesArr)
  }

}
